------------------
Flex Admin Support
------------------

Thank you for choosing Flex Admin. If you run into any issues with using this template, please don't hesitate to email us at help@startbootstrap.com.

Since you've purchased this template, you will receive dedicated email support as part of the purchase. We will try our best to answer your emails as soon as we can.
